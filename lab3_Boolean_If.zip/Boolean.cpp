#include <gtest/gtest.h>

/// Проверяет, является ли число положительным.
/// Задача Boolean1.
bool is_positive(int number) {
    return number > 0;
}

/// Проверка положительного числа.
TEST(Boolean1, PositiveNumber) {
    // Arrange
    int number = 5;

    // Act
    bool result = is_positive(number);

    // Assert
    EXPECT_TRUE(result);
}

/// Проверка отрицательного числа.
TEST(Boolean1, NegativeNumber) {
    // Arrange
    int number = -5;

    // Act
    bool result = is_positive(number);

    // Assert
    EXPECT_FALSE(result);
}

/// Проверка нуля.
TEST(Boolean1, Zero) {
    // Arrange
    int number = 0;

    // Act
    bool result = is_positive(number);

    // Assert
    EXPECT_FALSE(result);
}
