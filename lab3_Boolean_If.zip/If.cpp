#include <gtest/gtest.h>

/// Увеличивает положительное число на единицу.
/// Задача If1.
int increase_if_positive(int number) {
    if (number > 0) {
        number++;
    }

    return number;
}

/// Проверка положительного числа.
TEST(If1, PositiveNumber) {
    // Arrange
    int number = 5;

    // Act
    int result = increase_if_positive(number);

    // Assert
    EXPECT_EQ(result, 6);
}

/// Проверка отрицательного числа.
TEST(If1, NegativeNumber) {
    // Arrange
    int number = -5;

    // Act
    int result = increase_if_positive(number);

    // Assert
    EXPECT_EQ(result, -5);
}

/// Проверка нуля.
TEST(If1, Zero) {
    // Arrange
    int number = 0;

    // Act
    int result = increase_if_positive(number);

    // Assert
    EXPECT_EQ(result, 0);
}
